const User = require('../models/User');

class UserController {
    // Registrar nuevo usuario
    static async register(req, res) {
        try {
            const { nombre, apellido, documento, telefono, correo, password } = req.body;
            
            // Validaciones básicas
            if (!nombre || !apellido || !documento || !telefono || !correo || !password) {
                return res.status(400).json({
                    success: false,
                    message: 'Todos los campos son obligatorios'
                });
            }
            
            // Validar formato de email
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(correo)) {
                return res.status(400).json({
                    success: false,
                    message: 'Formato de email inválido'
                });
            }
            
            // Validar longitud de contraseña
            if (password.length < 6) {
                return res.status(400).json({
                    success: false,
                    message: 'La contraseña debe tener al menos 6 caracteres'
                });
            }
            
            const result = await User.create({
                nombre, apellido, documento, telefono, correo, password
            });
            
            res.status(201).json(result);
        } catch (error) {
            res.status(400).json({
                success: false,
                message: error.message
            });
        }
    }
    
    // Iniciar sesión
    static async login(req, res) {
        try {
            const { correo, password } = req.body;
            
            if (!correo || !password) {
                return res.status(400).json({
                    success: false,
                    message: 'Email y contraseña son obligatorios'
                });
            }
            
            // Buscar usuario
            const user = await User.findByEmail(correo);
            if (!user) {
                return res.status(401).json({
                    success: false,
                    message: 'Credenciales inválidas'
                });
            }
            
            // Validar contraseña
            const isValidPassword = await User.validatePassword(password, user.password_hash);
            if (!isValidPassword) {
                return res.status(401).json({
                    success: false,
                    message: 'Credenciales inválidas'
                });
            }
            
            // Respuesta exitosa (sin incluir la contraseña)
            const { password_hash, ...userInfo } = user;
            res.json({
                success: true,
                message: 'Inicio de sesión exitoso',
                user: userInfo
            });
        } catch (error) {
            res.status(500).json({
                success: false,
                message: 'Error interno del servidor'
            });
        }
    }
    
    // Obtener perfil de usuario
    static async getProfile(req, res) {
        try {
            const { userId } = req.params;
            
            const user = await User.findById(userId);
            if (!user) {
                return res.status(404).json({
                    success: false,
                    message: 'Usuario no encontrado'
                });
            }
            
            res.json({
                success: true,
                user
            });
        } catch (error) {
            res.status(500).json({
                success: false,
                message: error.message
            });
        }
    }
    
    // Obtener todos los usuarios
    static async getAllUsers(req, res) {
        try {
            const users = await User.findAll();
            res.json({
                success: true,
                users
            });
        } catch (error) {
            res.status(500).json({
                success: false,
                message: error.message
            });
        }
    }
    
    // Verificar si un email ya existe
    static async checkEmail(req, res) {
        try {
            const { email } = req.params;
            const user = await User.findByEmail(email);
            
            res.json({
                exists: !!user
            });
        } catch (error) {
            res.status(500).json({
                success: false,
                message: error.message
            });
        }
    }
    
    // Verificar si un documento ya existe
    static async checkDocument(req, res) {
        try {
            const { documento } = req.params;
            const user = await User.findByDocument(documento);
            
            res.json({
                exists: !!user
            });
        } catch (error) {
            res.status(500).json({
                success: false,
                message: error.message
            });
        }
    }
}

module.exports = UserController;