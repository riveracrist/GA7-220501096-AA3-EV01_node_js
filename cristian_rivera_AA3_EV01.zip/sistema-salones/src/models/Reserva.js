const { pool } = require('../config/database');

class Reserva {
    // Crear nueva reserva
    static async create(reservaData) {
        const { 
            idUsuario, 
            idSalon, 
            fechaReserva, 
            horaInicio, 
            horaFin, 
            motivoEvento, 
            observaciones 
        } = reservaData;
        
        try {
            const [result] = await pool.execute(
                'CALL SolicitarReserva(?, ?, ?, ?, ?, ?, ?)',
                [idUsuario, idSalon, fechaReserva, horaInicio, horaFin, motivoEvento, observaciones]
            );
            
            return {
                success: true,
                message: result[0][0].mensaje,
                reservaId: result[0][0].id_reserva,
                precioTotal: result[0][0].precio_total,
                duracionHoras: result[0][0].duracion_horas
            };
        } catch (error) {
            throw new Error(error.message);
        }
    }
    
    // Obtener reservas de un usuario
    static async findByUserId(userId) {
        try {
            const [rows] = await pool.execute(
                'SELECT * FROM vista_reservas_completa WHERE documento_identificacion = (SELECT documento_identificacion FROM usuarios WHERE id_usuario = ?) ORDER BY fecha_reserva DESC, hora_inicio',
                [userId]
            );
            return rows;
        } catch (error) {
            throw new Error('Error obteniendo reservas del usuario: ' + error.message);
        }
    }
    
    // Obtener reserva por ID
    static async findById(reservaId) {
        try {
            const [rows] = await pool.execute(
                'SELECT * FROM vista_reservas_completa WHERE id_reserva = ?',
                [reservaId]
            );
            return rows[0] || null;
        } catch (error) {
            throw new Error('Error buscando reserva: ' + error.message);
        }
    }
    
    // Obtener todas las reservas
    static async findAll(limit = 50) {
        try {
            const [rows] = await pool.execute(
                'SELECT * FROM vista_reservas_completa ORDER BY fecha_reserva DESC, hora_inicio LIMIT ?',
                [limit]
            );
            return rows;
        } catch (error) {
            throw new Error('Error obteniendo reservas: ' + error.message);
        }
    }
    
    // Actualizar estado de reserva
    static async updateStatus(reservaId, nuevoEstado) {
        try {
            const [result] = await pool.execute(
                'UPDATE reservas SET estado_reserva = ?, fecha_actualizacion = CURRENT_TIMESTAMP WHERE id_reserva = ?',
                [nuevoEstado, reservaId]
            );
            
            if (result.affectedRows === 0) {
                throw new Error('Reserva no encontrada');
            }
            
            return {
                success: true,
                message: 'Estado de reserva actualizado correctamente'
            };
        } catch (error) {
            throw new Error('Error actualizando estado: ' + error.message);
        }
    }
    
    // Cancelar reserva
    static async cancel(reservaId, userId) {
        try {
            const [result] = await pool.execute(
                'UPDATE reservas SET estado_reserva = "cancelada", fecha_actualizacion = CURRENT_TIMESTAMP WHERE id_reserva = ? AND id_usuario = ?',
                [reservaId, userId]
            );
            
            if (result.affectedRows === 0) {
                throw new Error('Reserva no encontrada o no autorizada');
            }
            
            return {
                success: true,
                message: 'Reserva cancelada correctamente'
            };
        } catch (error) {
            throw new Error('Error cancelando reserva: ' + error.message);
        }
    }
    
    // Obtener reservas por rango de fechas
    static async findByDateRange(fechaInicio, fechaFin) {
        try {
            const [rows] = await pool.execute(
                'SELECT * FROM vista_reservas_completa WHERE fecha_reserva BETWEEN ? AND ? ORDER BY fecha_reserva, hora_inicio',
                [fechaInicio, fechaFin]
            );
            return rows;
        } catch (error) {
            throw new Error('Error obteniendo reservas por rango de fechas: ' + error.message);
        }
    }
}

module.exports = Reserva;