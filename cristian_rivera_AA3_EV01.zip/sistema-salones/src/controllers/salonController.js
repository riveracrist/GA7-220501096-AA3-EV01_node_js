const Salon = require('../models/Salon');

class SalonController {
    // Obtener todos los salones disponibles
    static async getAvailableSalons(req, res) {
        try {
            const salons = await Salon.findAvailable();
            res.json({
                success: true,
                salones: salons
            });
        } catch (error) {
            res.status(500).json({
                success: false,
                message: error.message
            });
        }
    }
    
    // Obtener todos los salones
    static async getAllSalons(req, res) {
        try {
            const salons = await Salon.findAll();
            res.json({
                success: true,
                salones: salons
            });
        } catch (error) {
            res.status(500).json({
                success: false,
                message: error.message
            });
        }
    }
    
    // Obtener salón por ID
    static async getSalonById(req, res) {
        try {
            const { id } = req.params;
            
            if (!id || isNaN(id)) {
                return res.status(400).json({
                    success: false,
                    message: 'ID de salón inválido'
                });
            }
            
            const salon = await Salon.findById(id);
            if (!salon) {
                return res.status(404).json({
                    success: false,
                    message: 'Salón no encontrado'
                });
            }
            
            res.json({
                success: true,
                salon
            });
        } catch (error) {
            res.status(500).json({
                success: false,
                message: error.message
            });
        }
    }
    
    // Verificar disponibilidad de un salón
    static async checkAvailability(req, res) {
        try {
            const { id } = req.params;
            const { fecha, horaInicio, horaFin } = req.query;
            
            // Validaciones
            if (!fecha || !horaInicio || !horaFin) {
                return res.status(400).json({
                    success: false,
                    message: 'Fecha, hora de inicio y hora de fin son obligatorias'
                });
            }
            
            // Validar formato de fecha
            const fechaRegex = /^\d{4}-\d{2}-\d{2}$/;
            if (!fechaRegex.test(fecha)) {
                return res.status(400).json({
                    success: false,
                    message: 'Formato de fecha inválido (YYYY-MM-DD)'
                });
            }
            
            // Validar formato de hora
            const horaRegex = /^\d{2}:\d{2}:\d{2}$/;
            if (!horaRegex.test(horaInicio) || !horaRegex.test(horaFin)) {
                return res.status(400).json({
                    success: false,
                    message: 'Formato de hora inválido (HH:MM:SS)'
                });
            }
            
            const isAvailable = await Salon.checkAvailability(id, fecha, horaInicio, horaFin);
            const occupiedTimes = await Salon.getOccupiedTimes(id, fecha);
            
            res.json({
                success: true,
                disponible: isAvailable,
                horariosOcupados: occupiedTimes
            });
        } catch (error) {
            res.status(500).json({
                success: false,
                message: error.message
            });
        }
    }
    
    // Obtener horarios ocupados de un salón en una fecha
    static async getOccupiedTimes(req, res) {
        try {
            const { id } = req.params;
            const { fecha } = req.query;
            
            if (!fecha) {
                return res.status(400).json({
                    success: false,
                    message: 'La fecha es obligatoria'
                });
            }
            
            // Validar formato de fecha
            const fechaRegex = /^\d{4}-\d{2}-\d{2}$/;
            if (!fechaRegex.test(fecha)) {
                return res.status(400).json({
                    success: false,
                    message: 'Formato de fecha inválido (YYYY-MM-DD)'
                });
            }
            
            const occupiedTimes = await Salon.getOccupiedTimes(id, fecha);
            
            res.json({
                success: true,
                fecha,
                horariosOcupados: occupiedTimes
            });
        } catch (error) {
            res.status(500).json({
                success: false,
                message: error.message
            });
        }
    }
    
    // Obtener información completa de disponibilidad
    static async getAvailabilityInfo(req, res) {
        try {
            const { id } = req.params;
            const fecha = req.query.fecha || new Date().toISOString().split('T')[0];
            
            // Obtener información del salón
            const salon = await Salon.findById(id);
            if (!salon) {
                return res.status(404).json({
                    success: false,
                    message: 'Salón no encontrado'
                });
            }
            
            // Obtener horarios ocupados
            const occupiedTimes = await Salon.getOccupiedTimes(id, fecha);
            
            res.json({
                success: true,
                salon,
                fecha,
                horariosOcupados: occupiedTimes
            });
        } catch (error) {
            res.status(500).json({
                success: false,
                message: error.message
            });
        }
    }
}

module.exports = SalonController;