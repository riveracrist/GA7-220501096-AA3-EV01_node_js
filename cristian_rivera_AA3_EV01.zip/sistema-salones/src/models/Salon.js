const { pool } = require('../config/database');

class Salon {
    // Obtener todos los salones disponibles
    static async findAvailable() {
        try {
            const [rows] = await pool.execute(
                'SELECT * FROM vista_disponibilidad_salones ORDER BY numero_salon'
            );
            return rows;
        } catch (error) {
            throw new Error('Error obteniendo salones: ' + error.message);
        }
    }
    
    // Buscar salón por ID
    static async findById(id) {
        try {
            const [rows] = await pool.execute(
                'SELECT * FROM salones WHERE id_salon = ?',
                [id]
            );
            return rows[0] || null;
        } catch (error) {
            throw new Error('Error buscando salón: ' + error.message);
        }
    }
    
    // Verificar disponibilidad de un salón en una fecha y horario específico
    static async checkAvailability(salonId, fecha, horaInicio, horaFin) {
        try {
            const [rows] = await pool.execute(`
                SELECT COUNT(*) as conflictos
                FROM reservas 
                WHERE id_salon = ? 
                AND fecha_reserva = ? 
                AND estado_reserva IN ('confirmada', 'pendiente')
                AND (
                    (? >= hora_inicio AND ? < hora_fin) OR
                    (? > hora_inicio AND ? <= hora_fin) OR
                    (? <= hora_inicio AND ? >= hora_fin)
                )
            `, [salonId, fecha, horaInicio, horaInicio, horaFin, horaFin, horaInicio, horaFin]);
            
            return rows[0].conflictos === 0;
        } catch (error) {
            throw new Error('Error verificando disponibilidad: ' + error.message);
        }
    }
    
    // Obtener horarios ocupados de un salón en una fecha específica
    static async getOccupiedTimes(salonId, fecha) {
        try {
            const [rows] = await pool.execute(`
                SELECT hora_inicio, hora_fin, motivo_evento
                FROM reservas 
                WHERE id_salon = ? 
                AND fecha_reserva = ? 
                AND estado_reserva IN ('confirmada', 'pendiente')
                ORDER BY hora_inicio
            `, [salonId, fecha]);
            
            return rows;
        } catch (error) {
            throw new Error('Error obteniendo horarios ocupados: ' + error.message);
        }
    }
    
    // Obtener todos los salones (incluyendo los no disponibles)
    static async findAll() {
        try {
            const [rows] = await pool.execute(
                'SELECT * FROM salones ORDER BY numero_salon'
            );
            return rows;
        } catch (error) {
            throw new Error('Error obteniendo salones: ' + error.message);
        }
    }
}

module.exports = Salon;