// Variables globales
let currentUser = null;
const API_BASE = '/api';

// Inicialización cuando carga la página
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    setupEventListeners();
    loadSalons();
    setMinDate();
});

// Configurar fecha mínima (hoy)
function setMinDate() {
    const today = new Date().toISOString().split('T')[0];
    const fechaInput = document.querySelector('input[name="fechaReserva"]');
    if (fechaInput) {
        fechaInput.min = today;
    }
}

// Inicializar aplicación
function initializeApp() {
    // Verificar si hay sesión guardada
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
        currentUser = JSON.parse(savedUser);
        showUserInterface();
    }
}

// Configurar event listeners
function setupEventListeners() {
    // Formulario de login
    document.getElementById('loginForm').addEventListener('submit', handleLogin);
    
    // Formulario de registro
    document.getElementById('registerForm').addEventListener('submit', handleRegister);
    
    // Formulario de reserva
    document.getElementById('reservaForm').addEventListener('submit', handleReserva);
}

// Manejar login
async function handleLogin(e) {
    e.preventDefault();
    const form = e.target;
    const formData = new FormData(form);
    const data = Object.fromEntries(formData);
    
    try {
        showLoading(form);
        const response = await fetch(`${API_BASE}/users/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
        
        const result = await response.json();
        
        if (result.success) {
            currentUser = result.user;
            localStorage.setItem('currentUser', JSON.stringify(currentUser));
            showUserInterface();
            showAlert('success', 'Bienvenido ' + currentUser.nombre);
            showSection('salones');
        } else {
            showAlert('danger', result.message);
        }
    } catch (error) {
        console.error('Error en login:', error);
        showAlert('danger', 'Error de conexión. Intenta nuevamente.');
    } finally {
        hideLoading(form);
    }
}

// Manejar registro
async function handleRegister(e) {
    e.preventDefault();
    const form = e.target;
    const formData = new FormData(form);
    const data = Object.fromEntries(formData);
    
    try {
        showLoading(form);
        const response = await fetch(`${API_BASE}/users/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
        
        const result = await response.json();
        
        if (result.success) {
            showAlert('success', 'Usuario registrado exitosamente. Ahora puedes iniciar sesión.');
            form.reset();
            showSection('login');
        } else {
            showAlert('danger', result.message);
        }
    } catch (error) {
        console.error('Error en registro:', error);
        showAlert('danger', 'Error de conexión. Intenta nuevamente.');
    } finally {
        hideLoading(form);
    }
}

// Manejar nueva reserva
async function handleReserva(e) {
    e.preventDefault();
    const form = e.target;
    const formData = new FormData(form);
    const data = Object.fromEntries(formData);
    
    // Agregar ID del usuario actual
    data.idUsuario = currentUser.id_usuario;
    
    try {
        showLoading(form);
        
        // Primero verificar disponibilidad
        const availabilityResponse = await fetch(
            `${API_BASE}/salones/${data.idSalon}/availability?fecha=${data.fechaReserva}&horaInicio=${data.horaInicio}:00&horaFin=${data.horaFin}:00`
        );
        const availabilityResult = await availabilityResponse.json();
        
        if (!availabilityResult.disponible) {
            showAlert('warning', 'El salón no está disponible en el horario seleccionado.');
            return;
        }
        
        // Si está disponible, crear la reserva
        const response = await fetch(`${API_BASE}/reservas`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
        
        const result = await response.json();
        
        if (result.success) {
            showAlert('success', `Reserva creada exitosamente. Precio total: ${result.precioTotal.toLocaleString()}`);
            form.reset();
            loadUserReservas();
            showSection('mis-reservas');
        } else {
            showAlert('danger', result.message);
        }
    } catch (error) {
        console.error('Error creando reserva:', error);
        showAlert('danger', 'Error de conexión. Intenta nuevamente.');
    } finally {
        hideLoading(form);
    }
}

// Cargar salones
async function loadSalons() {
    try {
        const response = await fetch(`${API_BASE}/salones/available`);
        const result = await response.json();
        
        if (result.success) {
            displaySalons(result.salones);
            populateSalonSelect(result.salones);
        }
    } catch (error) {
        console.error('Error cargando salones:', error);
    }
}

// Mostrar salones en la interfaz
function displaySalons(salones) {
    const container = document.getElementById('salonesList');
    container.innerHTML = '';
    
    salones.forEach(salon => {
        const salonCard = `
            <div class="col-md-6 col-lg-4 mb-4">
                <div class="card salon-card h-100">
                    <div class="card-body">
                        <h5 class="card-title">
                            <i class="fas fa-door-open me-2"></i>${salon.nombre_salon}
                        </h5>
                        <p class="card-text">
                            <small class="text-muted">Número: ${salon.numero_salon}</small>
                        </p>
                        <p class="card-text">${salon.descripcion || 'Sin descripción'}</p>
                        <div class="row text-center">
                            <div class="col-6">
                                <i class="fas fa-users text-primary"></i>
                                <small class="d-block">Capacidad</small>
                                <strong>${salon.aforo} personas</strong>
                            </div>
                            <div class="col-6">
                                <i class="fas fa-dollar-sign text-success"></i>
                                <small class="d-block">Precio/hora</small>
                                <strong>${parseInt(salon.precio_hora).toLocaleString()}</strong>
                            </div>
                        </div>
                        <div class="mt-3">
                            <button class="btn btn-outline-primary btn-sm" onclick="checkAvailability(${salon.id_salon})">
                                <i class="fas fa-calendar-alt me-1"></i>Ver disponibilidad
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        container.innerHTML += salonCard;
    });
}

// Poblar select de salones
function populateSalonSelect(salones) {
    const select = document.querySelector('select[name="idSalon"]');
    select.innerHTML = '<option value="">Selecciona un salón</option>';
    
    salones.forEach(salon => {
        const option = document.createElement('option');
        option.value = salon.id_salon;
        option.textContent = `${salon.nombre_salon} - ${parseInt(salon.precio_hora).toLocaleString()}/hora`;
        select.appendChild(option);
    });
}

// Verificar disponibilidad de un salón
async function checkAvailability(salonId) {
    const fecha = prompt('Ingresa la fecha (YYYY-MM-DD):');
    if (!fecha) return;
    
    try {
        const response = await fetch(`${API_BASE}/salones/${salonId}/occupied-times?fecha=${fecha}`);
        const result = await response.json();
        
        if (result.success) {
            let message = `Disponibilidad para ${fecha}:\n\n`;
            
            if (result.horariosOcupados.length === 0) {
                message += 'El salón está disponible todo el día.';
            } else {
                message += 'Horarios ocupados:\n';
                result.horariosOcupados.forEach(horario => {
                    message += `• ${horario.hora_inicio.substring(0,5)} - ${horario.hora_fin.substring(0,5)}: ${horario.motivo_evento}\n`;
                });
            }
            
            alert(message);
        } else {
            showAlert('danger', result.message);
        }
    } catch (error) {
        console.error('Error verificando disponibilidad:', error);
        showAlert('danger', 'Error verificando disponibilidad.');
    }
}

// Cargar reservas del usuario
async function loadUserReservas() {
    if (!currentUser) return;
    
    try {
        const response = await fetch(`${API_BASE}/reservas/user/${currentUser.id_usuario}`);
        const result = await response.json();
        
        if (result.success) {
            displayReservas(result.reservas);
        }
    } catch (error) {
        console.error('Error cargando reservas:', error);
    }
}

// Mostrar reservas en la interfaz
function displayReservas(reservas) {
    const container = document.getElementById('reservasList');
    container.innerHTML = '';
    
    if (reservas.length === 0) {
        container.innerHTML = `
            <div class="text-center py-5">
                <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
                <h5 class="text-muted">No tienes reservas aún</h5>
                <button class="btn btn-primary mt-2" onclick="showSection('nueva-reserva')">
                    Crear primera reserva
                </button>
            </div>
        `;
        return;
    }
    
    reservas.forEach(reserva => {
        const statusClass = getStatusClass(reserva.estado_reserva);
        const statusText = getStatusText(reserva.estado_reserva);
        const isPast = new Date(reserva.fecha_reserva) < new Date();
        
        const reservaCard = `
            <div class="card reserva-card mb-3">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-8">
                            <h5 class="card-title">
                                <i class="fas fa-building me-2"></i>${reserva.nombre_salon}
                                <span class="badge ${statusClass} ms-2">${statusText}</span>
                            </h5>
                            <p class="card-text">
                                <i class="fas fa-calendar me-2"></i><strong>Fecha:</strong> ${formatDate(reserva.fecha_reserva)}<br>
                                <i class="fas fa-clock me-2"></i><strong>Horario:</strong> ${reserva.hora_inicio.substring(0,5)} - ${reserva.hora_fin.substring(0,5)}<br>
                                <i class="fas fa-hourglass-half me-2"></i><strong>Duración:</strong> ${reserva.duracion_horas} horas<br>
                                <i class="fas fa-dollar-sign me-2"></i><strong>Precio:</strong> ${parseInt(reserva.precio_total).toLocaleString()}
                            </p>
                            <p class="card-text">
                                <strong>Motivo:</strong> ${reserva.motivo_evento || 'Sin especificar'}
                            </p>
                            ${reserva.observaciones ? `<p class="card-text"><strong>Observaciones:</strong> ${reserva.observaciones}</p>` : ''}
                        </div>
                        <div class="col-md-4 text-end">
                            <small class="text-muted">Solicitada: ${formatDateTime(reserva.fecha_solicitud)}</small>
                            <div class="mt-2">
                                ${reserva.estado_reserva === 'pendiente' && !isPast ? 
                                    `<button class="btn btn-danger btn-sm" onclick="cancelReserva(${reserva.id_reserva})">
                                        <i class="fas fa-times"></i> Cancelar
                                    </button>` : ''
                                }
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        container.innerHTML += reservaCard;
    });
}

// Cancelar reserva
async function cancelReserva(reservaId) {
    if (!confirm('¿Estás seguro de que deseas cancelar esta reserva?')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/reservas/${reservaId}/cancel`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ userId: currentUser.id_usuario })
        });
        
        const result = await response.json();
        
        if (result.success) {
            showAlert('success', 'Reserva cancelada exitosamente.');
            loadUserReservas();
        } else {
            showAlert('danger', result.message);
        }
    } catch (error) {
        console.error('Error cancelando reserva:', error);
        showAlert('danger', 'Error cancelando reserva.');
    }
}

// Utilidades para estados
function getStatusClass(status) {
    const classes = {
        'pendiente': 'bg-warning',
        'confirmada': 'bg-success',
        'cancelada': 'bg-danger',
        'completada': 'bg-info'
    };
    return classes[status] || 'bg-secondary';
}

function getStatusText(status) {
    const texts = {
        'pendiente': 'Pendiente',
        'confirmada': 'Confirmada',
        'cancelada': 'Cancelada',
        'completada': 'Completada'
    };
    return texts[status] || 'Desconocido';
}

// Formatear fecha
function formatDate(dateString) {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('es-ES', options);
}

// Formatear fecha y hora
function formatDateTime(dateTimeString) {
    const options = { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    };
    return new Date(dateTimeString).toLocaleDateString('es-ES', options);
}

// Mostrar interfaz de usuario logueado
function showUserInterface() {
    document.getElementById('authSection').style.display = 'none';
    document.getElementById('userSection').style.display = 'block';
    document.getElementById('userInfo').style.display = 'block';
    document.getElementById('welcomeUser').textContent = `Hola, ${currentUser.nombre}`;
    loadUserReservas();
}

// Cerrar sesión
function logout() {
    currentUser = null;
    localStorage.removeItem('currentUser');
    
    // Mostrar sección de autenticación
    document.getElementById('authSection').style.display = 'block';
    document.getElementById('userSection').style.display = 'none';
    document.getElementById('userInfo').style.display = 'none';
    
    showSection('login');
    showAlert('info', 'Sesión cerrada correctamente.');
}

// Cambiar sección activa
function showSection(sectionId) {
    // Ocultar todas las secciones
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Mostrar sección seleccionada
    document.getElementById(sectionId).classList.add('active');
    
    // Actualizar navegación activa
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });
    
    // Marcar enlace activo
    const activeLink = document.querySelector(`[onclick="showSection('${sectionId}')"]`);
    if (activeLink) {
        activeLink.classList.add('active');
    }
    
    // Cargar datos específicos de la sección
    if (sectionId === 'mis-reservas' && currentUser) {
        loadUserReservas();
    } else if (sectionId === 'salones') {
        loadSalons();
    }
}

// Mostrar loading en botón
function showLoading(form) {
    const button = form.querySelector('button[type="submit"]');
    const loading = button.querySelector('.loading');
    if (loading) {
        loading.classList.add('show');
    }
    button.disabled = true;
}

// Ocultar loading en botón
function hideLoading(form) {
    const button = form.querySelector('button[type="submit"]');
    const loading = button.querySelector('.loading');
    if (loading) {
        loading.classList.remove('show');
    }
    button.disabled = false;
}

// Mostrar alertas
function showAlert(type, message) {
    // Remover alertas existentes
    const existingAlerts = document.querySelectorAll('.alert');
    existingAlerts.forEach(alert => alert.remove());
    
    // Crear nueva alerta
    const alert = document.createElement('div');
    alert.className = `alert alert-${type} alert-dismissible fade show`;
    alert.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    // Insertar al inicio del contenido principal
    const mainContent = document.querySelector('.main-content');
    mainContent.insertBefore(alert, mainContent.firstChild);
    
    // Auto-remover después de 5 segundos
    setTimeout(() => {
        if (alert && alert.parentNode) {
            alert.remove();
        }
    }, 5000);
}