const Reserva = require('../models/Reserva');

class ReservaController {
    // Crear nueva reserva
    static async createReserva(req, res) {
        try {
            const { 
                idUsuario, 
                idSalon, 
                fechaReserva, 
                horaInicio, 
                horaFin, 
                motivoEvento, 
                observaciones 
            } = req.body;
            
            // Validaciones básicas
            if (!idUsuario || !idSalon || !fechaReserva || !horaInicio || !horaFin) {
                return res.status(400).json({
                    success: false,
                    message: 'Todos los campos obligatorios deben ser completados'
                });
            }
            
            // Validar formato de fecha
            const fechaRegex = /^\d{4}-\d{2}-\d{2}$/;
            if (!fechaRegex.test(fechaReserva)) {
                return res.status(400).json({
                    success: false,
                    message: 'Formato de fecha inválido (YYYY-MM-DD)'
                });
            }
            
            // Validar formato de hora
            const horaRegex = /^\d{2}:\d{2}(:\d{2})?$/;
            if (!horaRegex.test(horaInicio) || !horaRegex.test(horaFin)) {
                return res.status(400).json({
                    success: false,
                    message: 'Formato de hora inválido (HH:MM o HH:MM:SS)'
                });
            }
            
            // Asegurar formato de segundos
            const formatHour = (hora) => {
                return hora.includes(':') && hora.split(':').length === 2 ? hora + ':00' : hora;
            };
            
            const reservaData = {
                idUsuario,
                idSalon,
                fechaReserva,
                horaInicio: formatHour(horaInicio),
                horaFin: formatHour(horaFin),
                motivoEvento: motivoEvento || 'Sin especificar',
                observaciones: observaciones || null
            };
            
            const result = await Reserva.create(reservaData);
            
            res.status(201).json(result);
        } catch (error) {
            res.status(400).json({
                success: false,
                message: error.message
            });
        }
    }
    
    // Obtener reservas de un usuario
    static async getUserReservas(req, res) {
        try {
            const { userId } = req.params;
            
            if (!userId || isNaN(userId)) {
                return res.status(400).json({
                    success: false,
                    message: 'ID de usuario inválido'
                });
            }
            
            const reservas = await Reserva.findByUserId(userId);
            
            res.json({
                success: true,
                reservas
            });
        } catch (error) {
            res.status(500).json({
                success: false,
                message: error.message
            });
        }
    }
    
    // Obtener reserva por ID
    static async getReservaById(req, res) {
        try {
            const { id } = req.params;
            
            if (!id || isNaN(id)) {
                return res.status(400).json({
                    success: false,
                    message: 'ID de reserva inválido'
                });
            }
            
            const reserva = await Reserva.findById(id);
            if (!reserva) {
                return res.status(404).json({
                    success: false,
                    message: 'Reserva no encontrada'
                });
            }
            
            res.json({
                success: true,
                reserva
            });
        } catch (error) {
            res.status(500).json({
                success: false,
                message: error.message
            });
        }
    }
    
    // Obtener todas las reservas
    static async getAllReservas(req, res) {
        try {
            const limit = parseInt(req.query.limit) || 50;
            const reservas = await Reserva.findAll(limit);
            
            res.json({
                success: true,
                reservas
            });
        } catch (error) {
            res.status(500).json({
                success: false,
                message: error.message
            });
        }
    }
    
    // Actualizar estado de reserva
    static async updateStatus(req, res) {
        try {
            const { id } = req.params;
            const { estado } = req.body;
            
            if (!id || isNaN(id)) {
                return res.status(400).json({
                    success: false,
                    message: 'ID de reserva inválido'
                });
            }
            
            const estadosValidos = ['pendiente', 'confirmada', 'cancelada', 'completada'];
            if (!estado || !estadosValidos.includes(estado)) {
                return res.status(400).json({
                    success: false,
                    message: 'Estado inválido. Estados válidos: ' + estadosValidos.join(', ')
                });
            }
            
            const result = await Reserva.updateStatus(id, estado);
            res.json(result);
        } catch (error) {
            res.status(400).json({
                success: false,
                message: error.message
            });
        }
    }
    
    // Cancelar reserva
    static async cancelReserva(req, res) {
        try {
            const { id } = req.params;
            const { userId } = req.body;
            
            if (!id || isNaN(id)) {
                return res.status(400).json({
                    success: false,
                    message: 'ID de reserva inválido'
                });
            }
            
            if (!userId || isNaN(userId)) {
                return res.status(400).json({
                    success: false,
                    message: 'ID de usuario inválido'
                });
            }
            
            const result = await Reserva.cancel(id, userId);
            res.json(result);
        } catch (error) {
            res.status(400).json({
                success: false,
                message: error.message
            });
        }
    }
    
    // Obtener reservas por rango de fechas
    static async getReservasByDateRange(req, res) {
        try {
            const { fechaInicio, fechaFin } = req.query;
            
            if (!fechaInicio || !fechaFin) {
                return res.status(400).json({
                    success: false,
                    message: 'Fecha de inicio y fecha de fin son obligatorias'
                });
            }
            
            // Validar formato de fecha
            const fechaRegex = /^\d{4}-\d{2}-\d{2}$/;
            if (!fechaRegex.test(fechaInicio) || !fechaRegex.test(fechaFin)) {
                return res.status(400).json({
                    success: false,
                    message: 'Formato de fecha inválido (YYYY-MM-DD)'
                });
            }
            
            const reservas = await Reserva.findByDateRange(fechaInicio, fechaFin);
            
            res.json({
                success: true,
                fechaInicio,
                fechaFin,
                reservas
            });
        } catch (error) {
            res.status(500).json({
                success: false,
                message: error.message
            });
        }
    }
}

module.exports = ReservaController;
            