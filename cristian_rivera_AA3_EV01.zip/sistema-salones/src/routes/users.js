const express = require('express');
const router = express.Router();
const UserController = require('../controllers/userController');

// Rutas de usuarios
router.post('/register', UserController.register);
router.post('/login', UserController.login);
router.get('/profile/:userId', UserController.getProfile);
router.get('/', UserController.getAllUsers);
router.get('/check-email/:email', UserController.checkEmail);
router.get('/check-document/:documento', UserController.checkDocument);

module.exports = router;