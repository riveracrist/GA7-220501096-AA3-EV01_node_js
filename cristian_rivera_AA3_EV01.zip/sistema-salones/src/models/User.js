const { pool } = require('../config/database');
const bcrypt = require('bcryptjs');

class User {
    // Registrar nuevo usuario
    static async create(userData) {
        const { nombre, apellido, documento, telefono, correo, password } = userData;
        
        try {
            // Encriptar contraseña
            const saltRounds = 12;
            const hashedPassword = await bcrypt.hash(password, saltRounds);
            
            // Usar el procedimiento almacenado
            const [result] = await pool.execute(
                'CALL RegistrarUsuario(?, ?, ?, ?, ?, ?)',
                [nombre, apellido, documento, telefono, correo, hashedPassword]
            );
            
            return {
                success: true,
                message: result[0][0].mensaje,
                userId: result[0][0].id_usuario
            };
        } catch (error) {
            throw new Error(error.message);
        }
    }
    
    // Buscar usuario por email
    static async findByEmail(email) {
        try {
            const [rows] = await pool.execute(
                'SELECT * FROM usuarios WHERE correo_electronico = ? AND estado = "activo"',
                [email]
            );
            return rows[0] || null;
        } catch (error) {
            throw new Error('Error buscando usuario: ' + error.message);
        }
    }
    
    // Buscar usuario por documento
    static async findByDocument(documento) {
        try {
            const [rows] = await pool.execute(
                'SELECT * FROM usuarios WHERE documento_identificacion = ? AND estado = "activo"',
                [documento]
            );
            return rows[0] || null;
        } catch (error) {
            throw new Error('Error buscando usuario: ' + error.message);
        }
    }
    
    // Buscar usuario por ID
    static async findById(id) {
        try {
            const [rows] = await pool.execute(
                'SELECT id_usuario, nombre, apellido, documento_identificacion, telefono, correo_electronico, fecha_registro, estado FROM usuarios WHERE id_usuario = ? AND estado = "activo"',
                [id]
            );
            return rows[0] || null;
        } catch (error) {
            throw new Error('Error buscando usuario: ' + error.message);
        }
    }
    
    // Validar contraseña
    static async validatePassword(plainPassword, hashedPassword) {
        return bcrypt.compare(plainPassword, hashedPassword);
    }
    
    // Obtener todos los usuarios activos
    static async findAll() {
        try {
            const [rows] = await pool.execute(
                'SELECT id_usuario, nombre, apellido, documento_identificacion, telefono, correo_electronico, fecha_registro FROM usuarios WHERE estado = "activo" ORDER BY fecha_registro DESC'
            );
            return rows;
        } catch (error) {
            throw new Error('Error obteniendo usuarios: ' + error.message);
        }
    }
}

module.exports = User;