const express = require('express');
const router = express.Router();
const SalonController = require('../controllers/salonController');

// Rutas de salones
router.get('/', SalonController.getAllSalons);
router.get('/available', SalonController.getAvailableSalons);
router.get('/:id', SalonController.getSalonById);
router.get('/:id/availability', SalonController.checkAvailability);
router.get('/:id/occupied-times', SalonController.getOccupiedTimes);
router.get('/:id/availability-info', SalonController.getAvailabilityInfo);

module.exports = router;