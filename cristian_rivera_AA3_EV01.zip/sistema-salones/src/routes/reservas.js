const express = require('express');
const router = express.Router();
const ReservaController = require('../controllers/reservaController');

// Rutas de reservas
router.post('/', ReservaController.createReserva);
router.get('/', ReservaController.getAllReservas);
router.get('/by-date-range', ReservaController.getReservasByDateRange);
router.get('/user/:userId', ReservaController.getUserReservas);
router.get('/:id', ReservaController.getReservaById);
router.put('/:id/status', ReservaController.updateStatus);
router.put('/:id/cancel', ReservaController.cancelReserva);

module.exports = router;